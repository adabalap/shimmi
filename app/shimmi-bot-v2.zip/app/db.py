from __future__ import annotations

import aiosqlite
import json
import logging
import os
from datetime import datetime
from typing import Optional, List, Tuple
from zoneinfo import ZoneInfo

from . import config

logger = logging.getLogger("app.db")
TZ = ZoneInfo(config.APP_TIMEZONE)
DB: Optional[aiosqlite.Connection] = None

DB_TRACE = os.getenv("DB_TRACE", "0").lower() in ("1", "true", "yes", "on")

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA foreign_keys=ON;
PRAGMA busy_timeout=3000;

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY,
  chat_id TEXT,
  sender_id TEXT,
  timestamp TEXT,
  role TEXT,
  content TEXT,
  summary TEXT,
  event_id TEXT,
  UNIQUE(chat_id, event_id)
);
CREATE INDEX IF NOT EXISTS idx_messages_chat_ts ON messages(chat_id, timestamp);

CREATE TABLE IF NOT EXISTS user_facts (
  id INTEGER PRIMARY KEY,
  sender_id TEXT NOT NULL,
  namespace TEXT NOT NULL DEFAULT 'default',
  attr_key TEXT NOT NULL,
  attr_value TEXT NOT NULL,
  value_type TEXT DEFAULT 'text',
  confidence REAL DEFAULT 0.95,
  source_msg_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(sender_id, namespace, attr_key)
);

CREATE TABLE IF NOT EXISTS record_types (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  schema_json TEXT NOT NULL,
  UNIQUE(name)
);

CREATE TABLE IF NOT EXISTS user_records (
  id INTEGER PRIMARY KEY,
  sender_id TEXT NOT NULL,
  record_type_id INTEGER NOT NULL,
  record_json TEXT NOT NULL,
  occurred_at TEXT,
  source_msg_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(record_type_id) REFERENCES record_types(id)
);

CREATE TABLE IF NOT EXISTS user_collections (
  id INTEGER PRIMARY KEY,
  sender_id TEXT NOT NULL,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(sender_id, name)
);

CREATE TABLE IF NOT EXISTS collection_items (
  id INTEGER PRIMARY KEY,
  collection_id INTEGER NOT NULL,
  item_text TEXT NOT NULL,
  status TEXT DEFAULT 'open',
  qty REAL,
  unit TEXT,
  meta_json TEXT,
  source_msg_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(collection_id) REFERENCES user_collections(id)
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_collection_items_unique_open ON collection_items(collection_id, item_text, status);

CREATE TABLE IF NOT EXISTS chat_prefs (
  chat_id TEXT PRIMARY KEY,
  observe_mode TEXT NOT NULL DEFAULT 'off',
  retention_days INTEGER NOT NULL DEFAULT 30,
  redaction_enabled INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL
);
"""


def _trace(sql: str, params: Tuple):
    if DB_TRACE:
        logger.info("🗄️ db.sql %s params=%s", sql.replace("\n", " ")[:220], params)


def _now_iso() -> str:
    return datetime.now(TZ).isoformat()


async def init_db():
    global DB
    DB = await aiosqlite.connect(config.DB_FILE)
    await DB.executescript(SCHEMA_SQL)
    await DB.commit()
    logger.info("🗄️ db.ready file=%s", config.DB_FILE)


async def close_db():
    global DB
    if DB:
        await DB.close()
        DB = None
        logger.info("🗄️ db.closed")


async def fetchall(query: str, params: Tuple = ()) -> List[Tuple]:
    if not DB:
        return []
    _trace(query, params)
    async with DB.execute(query, params) as cur:
        rows = await cur.fetchall()
    if DB_TRACE:
        logger.info("🗄️ db.rows n=%s", len(rows))
    return rows


async def execute(query: str, params: Tuple = ()) -> None:
    if not DB:
        return
    _trace(query, params)
    await DB.execute(query, params)
    await DB.commit()


async def save_message(chat_id: str, sender_id: str, role: str, content: str,
                       summary: str | None = None, event_id: str | None = None) -> Optional[int]:
    if not DB:
        return None
    ts = _now_iso()
    try:
        sql = "INSERT INTO messages (chat_id, sender_id, timestamp, role, content, summary, event_id) VALUES (?,?,?,?,?,?,?)"
        params = (chat_id, sender_id, ts, role, content, summary, event_id or None)
        _trace(sql, params)
        cur = await DB.execute(sql, params)
        await DB.commit()
        return cur.lastrowid
    except aiosqlite.IntegrityError:
        if DB_TRACE:
            logger.info("🗄️ db.insert dedup event")
        return None


async def upsert_fact(sender_id: str, key: str, value: str, value_type: str = 'text',
                      confidence: float = 0.95, namespace: str = 'default') -> None:
    if not DB or not key:
        return
    now = _now_iso()
    sql = (
        "INSERT INTO user_facts (sender_id, namespace, attr_key, attr_value, value_type, confidence, created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?) "
        "ON CONFLICT(sender_id, namespace, attr_key) DO UPDATE SET "
        "attr_value=excluded.attr_value, value_type=excluded.value_type, confidence=MIN(excluded.confidence, 1.0), updated_at=excluded.updated_at"
    )
    params = (sender_id, namespace, key, value, value_type, confidence, now, now)
    _trace(sql, params)
    await DB.execute(sql, params)
    await DB.commit()


async def ensure_record_type(name: str, schema_json: str) -> Optional[int]:
    if not DB:
        return None
    sql = "INSERT INTO record_types (name, schema_json) VALUES (?,?) ON CONFLICT(name) DO UPDATE SET schema_json=excluded.schema_json"
    _trace(sql, (name, "<schema>"))
    await DB.execute(sql, (name, schema_json))
    await DB.commit()
    rows = await fetchall("SELECT id FROM record_types WHERE name=?", (name,))
    return int(rows[0][0]) if rows else None


async def insert_user_record(sender_id: str, record_type: str, obj: dict,
                             occurred_at_iso: str | None = None,
                             source_msg_id: int | None = None) -> Optional[int]:
    type_id = await ensure_record_type(record_type, json.dumps({"type": "object"}))
    if not DB or not type_id:
        return None
    now = _now_iso()
    sql = (
        "INSERT INTO user_records (sender_id, record_type_id, record_json, occurred_at, source_msg_id, created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?)"
    )
    params = (sender_id, type_id, json.dumps(obj, ensure_ascii=False), occurred_at_iso, source_msg_id, now, now)
    _trace(sql, (sender_id, type_id, "<record_json>", occurred_at_iso, source_msg_id, now, now))
    cur = await DB.execute(sql, params)
    await DB.commit()
    return int(cur.lastrowid)


async def get_chat_prefs(chat_id: str) -> dict:
    # defaults can be set via env
    default_mode = os.getenv("OBSERVE_GROUPS_DEFAULT", "off").strip().lower()
    default_days = int(os.getenv("OBSERVE_RETENTION_DEFAULT_DAYS", "30"))
    default_red = 1 if os.getenv("OBSERVE_REDACTION_DEFAULT", "on").strip().lower() in ("1","true","yes","on") else 0

    if not DB:
        return {"observe_mode": default_mode, "retention_days": default_days, "redaction_enabled": default_red}
    rows = await fetchall("SELECT observe_mode, retention_days, redaction_enabled FROM chat_prefs WHERE chat_id=?", (chat_id,))
    if not rows:
        return {"observe_mode": default_mode, "retention_days": default_days, "redaction_enabled": default_red}
    return {"observe_mode": rows[0][0], "retention_days": int(rows[0][1]), "redaction_enabled": int(rows[0][2])}


async def set_chat_prefs(chat_id: str, *, observe_mode=None, retention_days=None, redaction_enabled=None) -> None:
    if not DB:
        return
    now = _now_iso()
    cur = await get_chat_prefs(chat_id)
    om = observe_mode if observe_mode is not None else cur["observe_mode"]
    rd = int(retention_days) if retention_days is not None else int(cur["retention_days"])
    re_ = int(redaction_enabled) if redaction_enabled is not None else int(cur["redaction_enabled"])
    sql = (
        "INSERT INTO chat_prefs (chat_id, observe_mode, retention_days, redaction_enabled, updated_at) VALUES (?,?,?,?,?) "
        "ON CONFLICT(chat_id) DO UPDATE SET observe_mode=excluded.observe_mode, retention_days=excluded.retention_days, "
        "redaction_enabled=excluded.redaction_enabled, updated_at=excluded.updated_at"
    )
    _trace(sql, (chat_id, om, rd, re_, now))
    await DB.execute(sql, (chat_id, om, rd, re_, now))
    await DB.commit()
